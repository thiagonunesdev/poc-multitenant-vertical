"use client";

import { useState } from "react";
import type { Tenant } from "@repo/core-config";
import { Card } from "@repo/ui";

interface TenantConfigFormProps {
  tenant: Tenant;
}

export function TenantConfigForm({ tenant }: TenantConfigFormProps) {
  const [primary, setPrimary] = useState(tenant.theme.primary);
  const [secondary, setSecondary] = useState(tenant.theme.secondary);

  const [title, setTitle] = useState(
    tenant.seo?.title ?? `${tenant.name} — Seminovos e ofertas`
  );
  const [description, setDescription] = useState(
    tenant.seo?.description ??
      "Página padrão de listagem de veículos e campanhas para este tenant."
  );

  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleSave() {
    // DEBUG: se isso não aparecer no console, o onClick não está rodando
    console.log("[TenantConfigForm] clicou em salvar para tenant", tenant.id);

    setSaving(true);
    setMessage(null);
    setError(null);

    try {
      const res = await fetch(
        `http://localhost:3003/tenants/${encodeURIComponent(tenant.id)}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            theme: {
              primary,
              secondary,
            },
            seo: {
              title,
              description,
            },
          }),
        }
      );

      if (!res.ok) {
        throw new Error(
          `Falha ao salvar configurações (status ${res.status}). Verifique se o JSON server de tenants está rodando na porta 3003.`
        );
      }

      setMessage("Configurações salvas com sucesso.");
    } catch (err) {
      const msg =
        err instanceof Error
          ? err.message
          : "Erro desconhecido ao salvar configurações.";
      setError(msg);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Card de tema */}
      <Card className="space-y-3">
        <h2 className="font-semibold text-lg">Tema (cores)</h2>
        <p className="text-xs text-slate-500">
          Altere as cores primária e secundária deste tenant. Use o color picker
          ou digite o valor em hex.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-slate-700">
          {/* Cor primária */}
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              Cor primária
            </label>
            <div className="flex items-center gap-3">
              {/* Color picker */}
              <input
                type="color"
                value={primary}
                onChange={(e) => setPrimary(e.target.value)}
                className="h-9 w-9 rounded border border-slate-200 p-0 cursor-pointer"
              />

              {/* Preview bolinha */}
              <span
                style={{
                  display: "inline-block",
                  width: 24,
                  height: 24,
                  borderRadius: 999,
                  border: "1px solid #cbd5f5",
                  backgroundColor: primary,
                }}
              />

              {/* Campo de texto com hex */}
              <input
                value={primary}
                onChange={(e) => setPrimary(e.target.value)}
                className="flex-1 rounded border border-slate-200 px-2 py-1 text-sm"
                placeholder="#2563eb"
              />
            </div>
          </div>

          {/* Cor secundária */}
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              Cor secundária
            </label>
            <div className="flex items-center gap-3">
              {/* Color picker */}
              <input
                type="color"
                value={secondary}
                onChange={(e) => setSecondary(e.target.value)}
                className="h-9 w-9 rounded border border-slate-200 p-0 cursor-pointer"
              />

              {/* Preview bolinha */}
              <span
                style={{
                  display: "inline-block",
                  width: 24,
                  height: 24,
                  borderRadius: 999,
                  border: "1px solid #cbd5f5",
                  backgroundColor: secondary,
                }}
              />

              {/* Campo de texto com hex */}
              <input
                value={secondary}
                onChange={(e) => setSecondary(e.target.value)}
                className="flex-1 rounded border border-slate-200 px-2 py-1 text-sm"
                placeholder="#1d4ed8"
              />
            </div>
          </div>
        </div>
      </Card>

      {/* Card de SEO */}
      <Card className="space-y-3">
        <h2 className="font-semibold text-lg">SEO padrão</h2>
        <p className="text-xs text-slate-500">
          Título e descrição padrão usados pelo storefront nas páginas
          principais deste tenant.
        </p>

        <div className="space-y-4 text-sm text-slate-700">
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              Título (title)
            </label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full rounded border border-slate-200 px-2 py-1 text-sm"
              placeholder="ACME Motors — Seminovos de qualidade"
            />
          </div>

          <div>
            <label className="block text-xs text-slate-500 mb-1">
              Descrição (meta description)
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full rounded border border-slate-200 px-2 py-1 text-sm resize-none"
              placeholder="Encontre o carro perfeito com ofertas especiais, financiamento flexível e garantia ACME."
            />
          </div>
        </div>
      </Card>

      {/* Rodapé com mensagens + botão nativo */}
      <div className="flex items-center justify-between gap-3 pt-2 text-xs">
        <div className="space-y-1">
          {message && <p className="text-emerald-600 font-medium">{message}</p>}
          {error && <p className="text-red-600 font-medium">{error}</p>}
        </div>

        <button
          type="button"
          onClick={handleSave}
          disabled={saving}
          className="inline-flex items-center justify-center rounded-md bg-slate-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {saving ? "Salvando configurações..." : "Salvar configurações"}
        </button>
      </div>
    </div>
  );
}
