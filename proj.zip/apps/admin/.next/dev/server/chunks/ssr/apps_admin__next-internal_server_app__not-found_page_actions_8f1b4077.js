module.exports = [
"[project]/apps/admin/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=apps_admin__next-internal_server_app__not-found_page_actions_8f1b4077.js.map