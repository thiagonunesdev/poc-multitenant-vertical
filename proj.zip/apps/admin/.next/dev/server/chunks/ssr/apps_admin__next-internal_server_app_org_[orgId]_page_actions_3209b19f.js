module.exports = [
"[project]/apps/admin/.next-internal/server/app/org/[orgId]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=apps_admin__next-internal_server_app_org_%5BorgId%5D_page_actions_3209b19f.js.map