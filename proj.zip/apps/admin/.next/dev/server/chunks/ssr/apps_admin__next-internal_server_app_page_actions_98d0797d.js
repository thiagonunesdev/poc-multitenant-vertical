module.exports = [
"[project]/apps/admin/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=apps_admin__next-internal_server_app_page_actions_98d0797d.js.map