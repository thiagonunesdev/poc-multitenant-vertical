(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_0e4e1483._.js",
  "static/chunks/_5db27a7f._.js"
],
    source: "dynamic"
});
