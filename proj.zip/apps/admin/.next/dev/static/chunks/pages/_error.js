__turbopack_load_page_chunks__("/_error", [
  "static/chunks/275cd_next_dist_compiled_8d861880._.js",
  "static/chunks/275cd_next_dist_shared_lib_6086d6af._.js",
  "static/chunks/275cd_next_dist_client_3887e3eb._.js",
  "static/chunks/275cd_next_dist_22217fac._.js",
  "static/chunks/275cd_next_error_3be7897a.js",
  "static/chunks/[next]_entry_page-loader_ts_218e72b8._.js",
  "static/chunks/76102_react-dom_44795136._.js",
  "static/chunks/node_modules__pnpm_7136f466._.js",
  "static/chunks/[root-of-the-server]__a0b7b665._.js",
  "static/chunks/apps_admin_pages__error_2da965e7._.js",
  "static/chunks/turbopack-apps_admin_pages__error_c623de42._.js"
])
