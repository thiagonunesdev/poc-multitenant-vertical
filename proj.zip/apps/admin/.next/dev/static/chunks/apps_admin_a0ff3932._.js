(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0eb3f4d8._.js",
  "static/chunks/275cd_next_dist_compiled_react-dom_4112948c._.js",
  "static/chunks/275cd_next_dist_compiled_react-server-dom-turbopack_cb687b00._.js",
  "static/chunks/275cd_next_dist_compiled_next-devtools_index_f9fb729c.js",
  "static/chunks/275cd_next_dist_compiled_d18cae9f._.js",
  "static/chunks/275cd_next_dist_client_44a4f487._.js",
  "static/chunks/275cd_next_dist_3620cbe5._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
