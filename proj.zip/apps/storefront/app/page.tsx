import { JSX } from "react";

export default function HomePage(): JSX.Element {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center gap-4">
      <h1 className="text-2xl font-semibold">POC Multitenant – Storefront</h1>
      <p className="text-sm text-slate-600">
        Use a rota{" "}
        <code className="px-1 py-0.5 rounded bg-slate-200 text-xs">
          /org/acme_motors/anuncios
        </code>{" "}
        para ver a listagem SSR de anúncios por organização.
      </p>
    </main>
  );
}
