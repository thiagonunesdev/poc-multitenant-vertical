import type { JSX, ReactNode } from "react";
import type { Tenant } from "@repo/core-config";

export const revalidate = 30;

interface OrgLayoutProps {
  children: ReactNode;
  params: Promise<{
    orgId: string;
  }>;
}

async function loadTenant(orgId: string): Promise<Tenant> {
  const res = await fetch(
    `http://localhost:3003/tenants?id=${encodeURIComponent(orgId)}`,
    {
      next: { revalidate: 30 },
    }
  );

  if (!res.ok) {
    throw new Error(
      `Falha ao buscar tenant ${orgId} no layout (status ${res.status})`
    );
  }

  const tenants = (await res.json()) as Tenant[];
  const tenant = tenants[0];

  if (!tenant) {
    throw new Error(`Tenant ${orgId} não encontrado no layout`);
  }

  return tenant;
}

export default async function OrgLayout(
  props: OrgLayoutProps
): Promise<JSX.Element> {
  const { orgId } = await props.params;
  const tenant = await loadTenant(orgId);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <header
        className="border-b"
        style={{ backgroundColor: tenant.theme.primary }}
      >
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img
              src={tenant.logoUrl}
              alt={tenant.name}
              className="h-8 w-auto rounded bg-white/10 p-1"
            />
            <div className="flex flex-col">
              <span className="text-sm font-semibold text-white">
                {tenant.name}
              </span>
              <span className="text-xs text-white/80">
                Org: {tenant.id} · País: {tenant.country}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-white/90">
            <span>Default lang: {tenant.defaultLang}</span>
            <span className="opacity-70">
              | Langs: {tenant.supportedLangs.join(", ")}
            </span>
          </div>
        </div>
      </header>

      <main className="flex-1 mx-auto max-w-6xl w-full px-4 py-6">
        {props.children}
      </main>

      <footer className="border-t bg-white">
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between text-xs text-slate-500">
          <span>
            POC Multitenant · {tenant.name} ({tenant.id})
          </span>
          <span>© {new Date().getFullYear()}</span>
        </div>
      </footer>
    </div>
  );
}
