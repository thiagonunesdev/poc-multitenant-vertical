module.exports=[40228,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_storefront__next-internal_server_app_sitemap_xml_route_actions_413c119c.js.map