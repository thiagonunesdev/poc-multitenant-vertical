module.exports=[79582,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_storefront__next-internal_server_app__global-error_page_actions_7a8de9e2.js.map