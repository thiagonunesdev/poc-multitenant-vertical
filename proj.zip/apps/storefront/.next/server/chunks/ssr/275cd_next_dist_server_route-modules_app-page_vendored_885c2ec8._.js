module.exports=[8456,(a,b,c)=>{"use strict";b.exports=a.r(60441).vendored.contexts.AppRouterContext},85358,(a,b,c)=>{"use strict";b.exports=a.r(60441).vendored["react-ssr"].ReactServerDOMTurbopackClient}];

//# sourceMappingURL=275cd_next_dist_server_route-modules_app-page_vendored_885c2ec8._.js.map