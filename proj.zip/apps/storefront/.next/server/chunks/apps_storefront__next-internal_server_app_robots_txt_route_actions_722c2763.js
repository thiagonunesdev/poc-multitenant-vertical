module.exports=[34204,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_storefront__next-internal_server_app_robots_txt_route_actions_722c2763.js.map