var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__5a7c92ea._.js")
R.c("server/chunks/[root-of-the-server]__66d56c75._.js")
R.c("server/chunks/apps_storefront__next-internal_server_app_robots_txt_route_actions_722c2763.js")
R.m(19330)
module.exports=R.m(19330).exports
