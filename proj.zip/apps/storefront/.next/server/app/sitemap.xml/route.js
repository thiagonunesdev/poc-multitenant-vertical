var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__3b4091dd._.js")
R.c("server/chunks/[root-of-the-server]__66d56c75._.js")
R.c("server/chunks/apps_storefront__next-internal_server_app_sitemap_xml_route_actions_413c119c.js")
R.m(45398)
module.exports=R.m(45398).exports
