(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/275cd_next_dist_4e3ccfeb._.js",
  "static/chunks/packages_ui_src_button_tsx_d27cb06c._.js"
],
    source: "dynamic"
});
