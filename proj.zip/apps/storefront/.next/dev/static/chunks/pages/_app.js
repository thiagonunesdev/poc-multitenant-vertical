__turbopack_load_page_chunks__("/_app", [
  "static/chunks/275cd_next_dist_compiled_8d861880._.js",
  "static/chunks/275cd_next_dist_shared_lib_535bf107._.js",
  "static/chunks/275cd_next_dist_client_3887e3eb._.js",
  "static/chunks/275cd_next_dist_bcc0f6b4._.js",
  "static/chunks/275cd_next_app_beb66603.js",
  "static/chunks/[next]_entry_page-loader_ts_b3f29451._.js",
  "static/chunks/76102_react-dom_44795136._.js",
  "static/chunks/node_modules__pnpm_7136f466._.js",
  "static/chunks/[root-of-the-server]__5b342d1c._.js",
  "static/chunks/apps_storefront_pages__app_2da965e7._.js",
  "static/chunks/turbopack-apps_storefront_pages__app_b47c8612._.js"
])
