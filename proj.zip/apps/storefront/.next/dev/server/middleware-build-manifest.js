globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/275cd_next_dist_compiled_8d861880._.js",
      "static/chunks/275cd_next_dist_shared_lib_535bf107._.js",
      "static/chunks/275cd_next_dist_client_3887e3eb._.js",
      "static/chunks/275cd_next_dist_bcc0f6b4._.js",
      "static/chunks/275cd_next_app_beb66603.js",
      "static/chunks/[next]_entry_page-loader_ts_b3f29451._.js",
      "static/chunks/76102_react-dom_44795136._.js",
      "static/chunks/node_modules__pnpm_7136f466._.js",
      "static/chunks/[root-of-the-server]__5b342d1c._.js",
      "static/chunks/apps_storefront_pages__app_2da965e7._.js",
      "static/chunks/turbopack-apps_storefront_pages__app_b47c8612._.js"
    ],
    "/_error": [
      "static/chunks/275cd_next_dist_compiled_8d861880._.js",
      "static/chunks/275cd_next_dist_shared_lib_6086d6af._.js",
      "static/chunks/275cd_next_dist_client_3887e3eb._.js",
      "static/chunks/275cd_next_dist_22217fac._.js",
      "static/chunks/275cd_next_error_3be7897a.js",
      "static/chunks/[next]_entry_page-loader_ts_218e72b8._.js",
      "static/chunks/76102_react-dom_44795136._.js",
      "static/chunks/node_modules__pnpm_7136f466._.js",
      "static/chunks/[root-of-the-server]__dca0bdea._.js",
      "static/chunks/apps_storefront_pages__error_2da965e7._.js",
      "static/chunks/turbopack-apps_storefront_pages__error_c6567b29._.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/275cd_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0eb3f4d8._.js",
    "static/chunks/275cd_next_dist_compiled_react-dom_4112948c._.js",
    "static/chunks/275cd_next_dist_compiled_react-server-dom-turbopack_cb687b00._.js",
    "static/chunks/275cd_next_dist_compiled_next-devtools_index_f9fb729c.js",
    "static/chunks/275cd_next_dist_compiled_d18cae9f._.js",
    "static/chunks/275cd_next_dist_client_44a4f487._.js",
    "static/chunks/275cd_next_dist_3620cbe5._.js",
    "static/chunks/69652_@swc_helpers_cjs_679851cc._.js",
    "static/chunks/apps_storefront_a0ff3932._.js",
    "static/chunks/turbopack-apps_storefront_696a6598._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];