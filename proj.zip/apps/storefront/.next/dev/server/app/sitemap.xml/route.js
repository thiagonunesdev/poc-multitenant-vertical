var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/275cd_next_f54f2ad4._.js")
R.c("server/chunks/[root-of-the-server]__2f581f69._.js")
R.c("server/chunks/apps_storefront__next-internal_server_app_sitemap_xml_route_actions_413c119c.js")
R.m("[project]/node_modules/.pnpm/next@16.0.3_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/storefront/app/sitemap--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/.pnpm/next@16.0.3_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/storefront/app/sitemap--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
