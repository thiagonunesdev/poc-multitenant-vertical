module.exports = [
"[project]/apps/storefront/.next-internal/server/app/org/[orgId]/anuncios/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=3cd3d__next-internal_server_app_org_%5BorgId%5D_anuncios_%5Bid%5D_page_actions_c0883251.js.map