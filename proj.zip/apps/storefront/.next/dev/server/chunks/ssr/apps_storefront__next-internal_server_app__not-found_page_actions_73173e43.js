module.exports = [
"[project]/apps/storefront/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=apps_storefront__next-internal_server_app__not-found_page_actions_73173e43.js.map