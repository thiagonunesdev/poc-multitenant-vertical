module.exports = [
"[project]/apps/storefront/.next-internal/server/app/org/[orgId]/anuncios/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=0da96_storefront__next-internal_server_app_org_%5BorgId%5D_anuncios_page_actions_878e2489.js.map