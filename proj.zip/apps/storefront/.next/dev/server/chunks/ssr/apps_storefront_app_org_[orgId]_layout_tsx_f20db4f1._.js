module.exports = [
"[project]/apps/storefront/app/org/[orgId]/layout.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OrgLayout
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.3_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
async function loadTenant(orgId) {
    const res = await fetch(`http://localhost:3003/tenants?id=${encodeURIComponent(orgId)}`, {
        cache: "no-store"
    });
    if (!res.ok) {
        throw new Error(`Falha ao buscar tenant ${orgId}`);
    }
    const tenants = await res.json();
    const tenant = tenants[0];
    if (!tenant) {
        throw new Error(`Tenant ${orgId} não encontrado`);
    }
    return tenant;
}
async function OrgLayout(props) {
    const { orgId } = await props.params;
    const tenant = await loadTenant(orgId);
    // Só pra debug no terminal do Next:
    console.log("[OrgLayout] Tema:", tenant.id, tenant.theme);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        // aqui a gente pinta TUDO desse layout
        className: "min-h-screen flex flex-col",
        style: {
            // teste pedido: fundo cor primária, texto cor secundária
            backgroundColor: tenant.theme.primary,
            color: tenant.theme.secondary,
            // e ainda deixamos as vars disponíveis se quiser usar em filhos
            "--tenant-primary": tenant.theme.primary,
            "--tenant-secondary": tenant.theme.secondary
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "p-4 text-lg font-bold",
                children: [
                    tenant.name,
                    " (",
                    tenant.id,
                    ")"
                ]
            }, void 0, true, {
                fileName: "[project]/apps/storefront/app/org/[orgId]/layout.tsx",
                lineNumber: 56,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "flex-1 px-6 py-4",
                children: props.children
            }, void 0, false, {
                fileName: "[project]/apps/storefront/app/org/[orgId]/layout.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
                className: "p-4 text-xs opacity-80",
                children: [
                    "© ",
                    tenant.name
                ]
            }, void 0, true, {
                fileName: "[project]/apps/storefront/app/org/[orgId]/layout.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/storefront/app/org/[orgId]/layout.tsx",
        lineNumber: 41,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=apps_storefront_app_org_%5BorgId%5D_layout_tsx_f20db4f1._.js.map