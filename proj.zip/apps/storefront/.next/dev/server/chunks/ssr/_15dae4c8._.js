module.exports = [
"[project]/packages/core-config/src/domain/tenant.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/packages/core-config/src/domain/translations.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildTranslationMap",
    ()=>buildTranslationMap
]);
function buildTranslationMap(entries) {
    return entries.reduce((map, entry)=>{
        map[entry.key] = entry.value;
        return map;
    }, {});
}
}),
"[project]/packages/core-config/src/domain/announcement.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
}),
"[project]/packages/core-config/src/config/env.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// packages/core-config/src/config/env.ts
__turbopack_context__.s([
    "ANNOUNCEMENT_API_URL",
    ()=>ANNOUNCEMENT_API_URL,
    "I18N_API_URL",
    ()=>I18N_API_URL,
    "TENANT_API_URL",
    ()=>TENANT_API_URL,
    "apiBaseUrl",
    ()=>apiBaseUrl
]);
const apiBaseUrl = "http://localhost"; // usado como base se o path for relativo
const TENANT_API_URL = "http://localhost:3003/tenants";
const I18N_API_URL = "http://localhost:3001/translations";
const ANNOUNCEMENT_API_URL = "http://localhost:3002/announcements";
}),
"[project]/packages/core-config/src/http/httpClient.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "httpGet",
    ()=>httpGet
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$config$2f$env$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/config/env.ts [app-rsc] (ecmascript)");
;
async function httpGet({ path, searchParams, init }) {
    const url = new URL(path, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$config$2f$env$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["apiBaseUrl"]);
    if (searchParams) {
        Object.entries(searchParams).forEach(([key, value])=>{
            url.searchParams.set(key, value);
        });
    }
    const response = await fetch(url.toString(), {
        cache: "no-store",
        ...init
    });
    if (!response.ok) {
        throw new Error(`GET ${url.toString()} failed with status ${response.status}`);
    }
    return await response.json();
}
}),
"[project]/packages/core-config/src/http/tenantApi.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchTenantById",
    ()=>fetchTenantById
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$http$2f$httpClient$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/http/httpClient.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$config$2f$env$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/config/env.ts [app-rsc] (ecmascript)");
;
;
async function fetchTenantById(orgId) {
    const tenants = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$http$2f$httpClient$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["httpGet"])({
        path: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$config$2f$env$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["TENANT_API_URL"],
        searchParams: {
            id: orgId
        }
    });
    if (tenants.length === 0) {
        throw new Error(`Tenant not found for id ${orgId}`);
    }
    return tenants[0];
}
}),
"[project]/packages/core-config/src/http/i18nApi.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchTranslations",
    ()=>fetchTranslations
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$domain$2f$translations$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/domain/translations.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$http$2f$httpClient$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/http/httpClient.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$config$2f$env$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/config/env.ts [app-rsc] (ecmascript)");
;
;
;
async function fetchTranslations(tenantId, lang) {
    const entries = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$http$2f$httpClient$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["httpGet"])({
        path: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$config$2f$env$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["I18N_API_URL"],
        searchParams: {
            tenantId,
            lang
        }
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$domain$2f$translations$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["buildTranslationMap"])(entries);
}
}),
"[project]/packages/core-config/src/http/announcementApi.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchAnnouncementById",
    ()=>fetchAnnouncementById,
    "fetchAnnouncementsByTenant",
    ()=>fetchAnnouncementsByTenant
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$http$2f$httpClient$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/http/httpClient.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$config$2f$env$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/config/env.ts [app-rsc] (ecmascript)");
;
;
async function fetchAnnouncementsByTenant(tenantId) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$http$2f$httpClient$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["httpGet"])({
        path: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$config$2f$env$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ANNOUNCEMENT_API_URL"],
        searchParams: {
            tenantId
        }
    });
}
async function fetchAnnouncementById(tenantId, id) {
    const list = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$http$2f$httpClient$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["httpGet"])({
        path: ":3002/announcements",
        searchParams: {
            id,
            tenantId
        }
    });
    if (list.length === 0) {
        throw new Error(`Announcement ${id} not found`);
    }
    return list[0];
}
}),
"[project]/packages/core-config/src/index.ts [app-rsc] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// domain
__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$domain$2f$tenant$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/domain/tenant.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$domain$2f$translations$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/domain/translations.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$domain$2f$announcement$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/domain/announcement.ts [app-rsc] (ecmascript)");
// config
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$config$2f$env$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/config/env.ts [app-rsc] (ecmascript)");
// http (APIs)
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$http$2f$tenantApi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/http/tenantApi.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$http$2f$i18nApi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/http/i18nApi.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$http$2f$announcementApi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/http/announcementApi.ts [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
}),
"[project]/apps/storefront/app/org/[orgId]/layout.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OrgLayout,
    "revalidate",
    ()=>revalidate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.0.3_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/core-config/src/index.ts [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$http$2f$tenantApi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/http/tenantApi.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$http$2f$i18nApi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core-config/src/http/i18nApi.ts [app-rsc] (ecmascript)");
;
;
const revalidate = 30;
async function loadOrgLayoutData(orgId) {
    const tenant = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$http$2f$tenantApi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["fetchTenantById"])(orgId);
    const lang = tenant.defaultLang;
    const translations = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2d$config$2f$src$2f$http$2f$i18nApi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["fetchTranslations"])(tenant.id, lang);
    return {
        tenant,
        translations,
        lang
    };
}
async function OrgLayout({ params, children }) {
    const { orgId } = params;
    const { tenant } = await loadOrgLayoutData(orgId);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen flex flex-col",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "w-full px-6 py-4 flex items-center justify-between",
                style: {
                    backgroundColor: tenant.theme.primary
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "font-bold text-white text-lg",
                        children: tenant.name
                    }, void 0, false, {
                        fileName: "[project]/apps/storefront/app/org/[orgId]/layout.tsx",
                        lineNumber: 46,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xs text-white opacity-80",
                        children: [
                            "País: ",
                            tenant.country,
                            " · Org: ",
                            tenant.id
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/storefront/app/org/[orgId]/layout.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/storefront/app/org/[orgId]/layout.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "flex-1 px-6 py-6 bg-slate-50",
                children: children
            }, void 0, false, {
                fileName: "[project]/apps/storefront/app/org/[orgId]/layout.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$3_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
                className: "w-full px-6 py-4 text-xs text-white",
                style: {
                    backgroundColor: tenant.theme.secondary
                },
                children: [
                    tenant.name,
                    " © ",
                    new Date().getFullYear()
                ]
            }, void 0, true, {
                fileName: "[project]/apps/storefront/app/org/[orgId]/layout.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/storefront/app/org/[orgId]/layout.tsx",
        lineNumber: 41,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=_15dae4c8._.js.map