module.exports = [
"[project]/apps/storefront/.next-internal/server/app/org/[orgId]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=apps_storefront__next-internal_server_app_org_%5BorgId%5D_page_actions_371509fb.js.map