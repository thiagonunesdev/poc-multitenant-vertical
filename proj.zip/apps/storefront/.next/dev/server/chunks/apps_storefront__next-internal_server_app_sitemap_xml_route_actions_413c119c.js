module.exports = [
"[project]/apps/storefront/.next-internal/server/app/sitemap.xml/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=apps_storefront__next-internal_server_app_sitemap_xml_route_actions_413c119c.js.map