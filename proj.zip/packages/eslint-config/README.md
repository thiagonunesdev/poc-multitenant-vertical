# `@turbo/eslint-config`

Collection of internal eslint configurations.
